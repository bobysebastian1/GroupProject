import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, } from '@angular/forms';
import { Router } from '@angular/router';
import { WithdrawService } from '../withdraw.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  constructor( private formBuilder: FormBuilder,
    private router: Router,
    private transferService:WithdrawService) { }
  transferForm: FormGroup;
  loading = false;
  submitted = false;
  
  ngOnInit() {
    
   var username:String=localStorage.getItem("username");
   var accNo=+localStorage.getItem("savingAccNo");
   var accNo2=+localStorage.getItem("primaryAccNo");
   console.log(accNo2)
   console.log(accNo)
   console.log(username)
   this.transferForm = this.formBuilder.group({
      //username : username,
      account: accNo,
      //action: this.deposit,
      //account:['',[Validators.required]],
      amount:['',[Validators.required]]
  
  });

}
get saccountno(): any {
  return localStorage.getItem('savingAccNo');
}
get fval() { return this.transferForm.controls; }

  withdraw(){
    this.submitted = true;
    if (this.transferForm.invalid) {
      return;
    }
    this.loading = true;
    const result:any = Object.assign({}, this.transferForm.value);
        
    
    // Do useful stuff with the gathered data
    try{
      this.transferService.insertEntry(result.account,result.amount).subscribe(
        (data : any) =>{
         this.loading=false;
         if(data.withdrawStatus==false){
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.responseMessage,
          })
         }
         else{
          Swal.fire({
            icon: 'success',
            title: 'Transaction successful',
            text:data.responseMessage
          })
         }
         }
       );
    }catch{
      this.loading=false;
    }
      

  }

}
