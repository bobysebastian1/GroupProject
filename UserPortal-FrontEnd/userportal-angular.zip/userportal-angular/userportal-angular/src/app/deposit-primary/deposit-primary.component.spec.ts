import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepositPrimaryComponent } from './deposit-primary.component';

describe('DepositPrimaryComponent', () => {
  let component: DepositPrimaryComponent;
  let fixture: ComponentFixture<DepositPrimaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepositPrimaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositPrimaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
