export class PrimaryAccount{
    id:number;
    accno:number;
    balance:number;
    username:String;
    user:null;
}