import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, } from '@angular/forms';
import { Router } from '@angular/router';
import { TransactionService } from '../transaction.service';
import { TransferService } from '../transfer.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-transferprimary',
  templateUrl: './transferprimary.component.html',
  styleUrls: ['./transferprimary.component.css']
})
export class TransferprimaryComponent implements OnInit {

  username:String=localStorage.getItem("username");
  accNo:number=+localStorage.getItem("savingAccNo");
 public savingBalance:number;
 accNo2:number=+localStorage.getItem("primaryAccNo");
 public primaryBalance:number;

  constructor( private formBuilder: FormBuilder,
    private router: Router,
    private transferService: TransferService,
    private transactionService: TransactionService) { }
  transferForm: FormGroup;
  loading = false;
  submitted = false;
  
  ngOnInit() {
    
   var username:String=localStorage.getItem("username");
   var accNo:number=+localStorage.getItem("primaryAccNo");
   this.accNo = accNo;
   console.log(accNo)
   console.log(username)
   this.transferForm = this.formBuilder.group({
      username : username,
      saccountNo: accNo,
      ifscNo: ['', [Validators.required, Validators.minLength(8)]],
      raccountNo: ['', [Validators.required]],
      amount:['',[Validators.required]]
  
  });

  this.transactionService.getPrimaryAccount(this.username).subscribe(res=>{
    this.primaryBalance = res.balance;
    this.accNo2 = res.accno;
    console.log( this.primaryBalance);
    console.log( this.accNo2);

  });

}
get saccountno(): any {
  return localStorage.getItem('primaryAccNo');
}
get fval() { return this.transferForm.controls; }

  transfer(){
    this.submitted = true;
    if (this.transferForm.invalid) {
      return;
    }
    this.loading = true;
    const result:any = Object.assign({}, this.transferForm.value);
        
    
    // Do with the gathered data
    try{
      this.transferService.insertEntry(result.username,result.saccountNo,result.ifscNo,result.raccountNo,result.amount).subscribe(
        (data : any) =>{
         this.loading=false;
         if(data.transferStatus==true){
          Swal.fire({
            icon: 'success',
            title: 'Transaction successful',
            text:data.responseMessage
          })
         }
         else{
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.responseMessage,
          })
         }
         }
       );
    }catch{
      this.loading=false;
    }
      

  }
}





  
  
  
  

  

  

  



