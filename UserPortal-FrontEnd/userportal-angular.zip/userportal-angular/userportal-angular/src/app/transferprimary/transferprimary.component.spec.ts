import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferprimaryComponent } from './transferprimary.component';

describe('TransferprimaryComponent', () => {
  let component: TransferprimaryComponent;
  let fixture: ComponentFixture<TransferprimaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransferprimaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferprimaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
