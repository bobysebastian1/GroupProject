import { TestBed } from '@angular/core/testing';

import { TransferprimaryService } from './transferprimary.service';

describe('TransferprimaryService', () => {
  let service: TransferprimaryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TransferprimaryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
