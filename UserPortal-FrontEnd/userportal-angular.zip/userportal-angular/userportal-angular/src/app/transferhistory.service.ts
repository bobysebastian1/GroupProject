import { Injectable } from '@angular/core';
import {TransferHistory} from './_models/transferhistory';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SavingAccount } from './_models/savingaccount';
import { PrimaryAccount } from './_models/primaryaccount';

@Injectable({
  providedIn: 'root'
})
export class TransferhistoryService {

  private url:String;

  constructor(private http:HttpClient) {
    this.url="http://localhost:8081"
   }
   public getTransferHistory(accNo):Observable<TransferHistory[]>{
    return this.http.get<TransferHistory[]>(this.url+"/account/getTransfers/"+accNo);
  }
   public getSavingAccount(username):Observable<SavingAccount>{
     return this.http.get<SavingAccount>(this.url+"/account/getsaving/"+username);
  }
  public getPrimaryAccount(username):Observable<PrimaryAccount>{
    return this.http.get<PrimaryAccount>(this.url+"/account/getprimary/"+username);
 }

 
}
