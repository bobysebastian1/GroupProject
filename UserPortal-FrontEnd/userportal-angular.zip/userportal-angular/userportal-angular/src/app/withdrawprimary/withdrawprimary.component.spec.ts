import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WithdrawprimaryComponent } from './withdrawprimary.component';

describe('WithdrawprimaryComponent', () => {
  let component: WithdrawprimaryComponent;
  let fixture: ComponentFixture<WithdrawprimaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WithdrawprimaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WithdrawprimaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
