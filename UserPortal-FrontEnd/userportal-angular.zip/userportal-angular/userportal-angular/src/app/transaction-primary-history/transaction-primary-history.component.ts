import { Component, OnInit } from '@angular/core';
import { TransactionService } from '../transaction.service';
import { Transaction} from '../_models/transaction';
import { SavingAccount } from '../_models/savingaccount';
import { PrimaryAccount } from '../_models/primaryaccount';
import { UserDisplay } from '../_models/userdisplay';


@Component({
  selector: 'app-transaction-primary-history',
  templateUrl: './transaction-primary-history.component.html',
  styleUrls: ['./transaction-primary-history.component.css']
})
export class TransactionPrimaryHistoryComponent implements OnInit {

  username:String=localStorage.getItem("username");
  //accNo:number=+localStorage.getItem("savingAccNo");
 //public transactionList:Array<Transaction>;
 //public savingBalance:number;
 accNo:number=+localStorage.getItem("primaryAccno");
 public transactionList:Array<Transaction>;
 public primaryBalance:number;


  constructor(private transactionService:TransactionService) {}

  ngOnInit(): void {
      //this.transactionService.getTransactions(this.accNo).subscribe(res=>{
        //this.transactionList = res;
        //console.log(this.transactionList);
    //});
    //this.transactionService.getSavingAccount(this.username).subscribe(res=>{
      //this.savingBalance = res.balance;
      //console.log(this.savingBalance);

    //});
    this.transactionService.getTransactions(this.accNo).subscribe(res=>{
      this.transactionList = res;
      console.log(this.transactionList);

    });
    this.transactionService.getPrimaryAccount(this.username).subscribe(res=>{
      this.primaryBalance = res.balance;
      this.accNo = res.accno;
      console.log( this.primaryBalance);
      console.log( this.accNo);

    });
    
  }


}
