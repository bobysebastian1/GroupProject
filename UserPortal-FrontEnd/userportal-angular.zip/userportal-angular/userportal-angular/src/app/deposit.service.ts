import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DepositService {

  readonly rootUrl = 'http://localhost:8081';
  
    constructor(private http: HttpClient) { }
  
    insertEntry(account:string,amount:number) {
      var body = {
        account: account,
        amount:amount
      }
      console.log(body);
      return this.http.post(this.rootUrl + '/account/deposit', body);
    }
  
  
}
