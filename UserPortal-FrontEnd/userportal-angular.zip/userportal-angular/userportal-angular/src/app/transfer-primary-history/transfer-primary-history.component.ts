import { Component, OnInit } from '@angular/core';
import { TransferHistory} from '../_models/transferhistory'
import { TransferhistoryService } from '../transferhistory.service';

@Component({
  selector: 'app-transfer-primary-history',
  templateUrl: './transfer-primary-history.component.html',
  styleUrls: ['./transfer-primary-history.component.css']
})
export class TransferPrimaryHistoryComponent implements OnInit {

  accNo:number =+localStorage.getItem("primaryAccNo");
  username:String=localStorage.getItem("username");
  public transferList:Array<TransferHistory>;
  public primaryBalance:number;

  constructor(private transferService:TransferhistoryService) { }

  ngOnInit(): void {
    this.transferService.getTransferHistory(this.accNo).subscribe(res=>{
      this.transferList=res;
      console.log(this.transferList);
    });
    this.transferService.getPrimaryAccount(this.username).subscribe(res=>{
      this.primaryBalance = res.balance;
    });
  }

}
