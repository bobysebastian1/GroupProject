import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferPrimaryHistoryComponent } from './transfer-primary-history.component';

describe('TransferPrimaryHistoryComponent', () => {
  let component: TransferPrimaryHistoryComponent;
  let fixture: ComponentFixture<TransferPrimaryHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransferPrimaryHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferPrimaryHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
