import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransactionPrimaryHistoryComponent } from './transaction-primary-history.component';

describe('TransactionPrimaryHistoryComponent', () => {
  let component: TransactionPrimaryHistoryComponent;
  let fixture: ComponentFixture<TransactionPrimaryHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransactionPrimaryHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransactionPrimaryHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
