import { Component, OnInit } from '@angular/core';
import { TransferHistory} from '../_models/transferhistory'
import { TransferhistoryService } from '../transferhistory.service';

@Component({
  selector: 'app-transfer-history',
  templateUrl: './transfer-history.component.html',
  styleUrls: ['./transfer-history.component.css']
})
export class TransferHistoryComponent implements OnInit {

  accNo:number =+localStorage.getItem("savingAccNo");
  username:String=localStorage.getItem("username");
  public transferList:Array<TransferHistory>;
  public savingBalance:number;

  constructor(private transferService:TransferhistoryService) { }

  ngOnInit(): void {
    this.transferService.getTransferHistory(this.accNo).subscribe(res=>{
      this.transferList=res;
      console.log(this.transferList);
    });
    this.transferService.getSavingAccount(this.username).subscribe(res=>{
      this.savingBalance = res.balance;
    });
  }

}
