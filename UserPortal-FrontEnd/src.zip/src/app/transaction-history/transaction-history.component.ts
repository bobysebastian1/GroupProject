import { Component, OnInit } from '@angular/core';
import { TransactionService } from '../transaction.service';
import { Transaction} from '../_models/transaction';
import { SavingAccount } from '../_models/savingaccount';
import { PrimaryAccount } from '../_models/primaryaccount';

@Component({
  selector: 'app-transaction-history',
  templateUrl: './transaction-history.component.html',
 styleUrls: ['./transaction-history.component.css']
})
export class TransactionHistoryComponent implements OnInit {

  username:String=localStorage.getItem("username");
  accNo:number=+localStorage.getItem("savingAccNo");
 public transactionList:Array<Transaction>;
 public savingBalance:number;
 accNo2:number=+localStorage.getItem("primaryAccNo");
 public transactionList2:Array<Transaction>;
 public primaryBalance:number;


  constructor(private transactionService:TransactionService) {}

  ngOnInit(): void {
      this.transactionService.getTransactions(this.accNo).subscribe(res=>{
        this.transactionList = res;
        console.log(this.transactionList);
    });
    this.transactionService.getSavingAccount(this.username).subscribe(res=>{
      this.savingBalance = res.balance;
      console.log(this.savingBalance);

    });
    this.transactionService.getTransactions(this.accNo2).subscribe(res=>{
      this.transactionList2 = res;
      console.log(this.transactionList2);

    });
    this.transactionService.getPrimaryAccount(this.username).subscribe(res=>{
      this.primaryBalance = res.balance;
      this.accNo2 = res.accno;
      console.log( this.primaryBalance);
      console.log( this.accNo2);

    });
    
  }

}

