package com.admin.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.admin.model.Transfer;
import com.admin.model.TransferImp;



@Repository
public interface TransferRepository extends JpaRepository<Transfer, Integer> {
	
	public List<Transfer> findBySaccount(long saccount);
	public List<Transfer> findByRaccount(long racoount);
	
	//@Query("SELECT new com.admin.model.TransferImp(t.id,t.amount,t.date,t.raccount,t.saccount)" + "FROM Transfer t")
	//public List<TransferImp> getAllTransactions();
	
}
