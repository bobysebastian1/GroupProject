import { Component, OnInit } from '@angular/core';
import { UsersService } from '../users.service';
import { UserData } from '../model/userData';

@Component({
  selector: 'app-userbalance',
  templateUrl: './userbalance.component.html',
  styleUrls: ['./userbalance.component.css']
})
export class UserbalanceComponent implements OnInit {

  users: any[]
  constructor( private service: UsersService) {

  }
  selectedValue: number;

  ngOnInit() {
    this.service.getAllUsers().subscribe(res => {
      console.log(res)
     this.users = res
     
    });
  }

}
