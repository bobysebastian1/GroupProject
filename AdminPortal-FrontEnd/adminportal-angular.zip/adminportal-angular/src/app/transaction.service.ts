import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Transaction } from './model/transactions';

@Injectable({
  providedIn: 'root',
})
export class TransactionService {
  private baseUrl = 'http://localhost:8084'; // Update with your backend API URL

  constructor(private http: HttpClient) {}

  getAllTransactions(): Observable<any[]> {
    const url = `${this.baseUrl}/user/allTransactions`;
    return this.http.get<any[]>(url);
  }
}
