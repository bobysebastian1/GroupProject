export interface Transaction {
    id: number;
    saccount: number;
    raccount: number;
    amount: number;
    date: string;
  }
  