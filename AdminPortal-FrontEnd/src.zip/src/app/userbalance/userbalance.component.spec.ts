import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserbalanceComponent } from './userbalance.component';

describe('UserbalanceComponent', () => {
  let component: UserbalanceComponent;
  let fixture: ComponentFixture<UserbalanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserbalanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserbalanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
